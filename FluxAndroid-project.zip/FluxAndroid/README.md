# FLUX Android Assistant (starter project)

A native Java Android Studio starter for Flux. It includes:
- Dark neon Flux UI and custom glowing orb
- Android speech recognition launch (device/provider dependent) and text command entry
- Text-to-speech responses
- Open installed apps by partial app name
- Time/date responses
- Alarm and timer hand-off to the Android Clock app
- Contact lookup with a confirmation dialog, then opens the dialer (does not silently place calls)
- Floating overlay bubble that opens Flux
- English/Hindi command keyword foundations

## Build
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install Android SDK Platform 35 / Build Tools when prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android device and grant microphone, contacts and overlay permissions when prompted.

## Important current limitations
This is a functional starter, not yet the complete always-on AI assistant requested:
- The floating bubble is implemented, but the animated listening/processing orb and waveform need a foreground voice-session UI.
- “Hey Flux” is not yet an always-listening wake-word engine. Android's general speech recognizer is not a safe/reliable continuous wake-word detector. Add a dedicated on-device wake-word model (for example, a licensed Porcupine model or a custom TensorFlow Lite model) and a microphone foreground service with a persistent notification.
- Offline speech recognition depends on an offline language pack/provider installed on the phone. The app's command matching itself runs locally.
- Online generative AI is not connected. Add a backend endpoint and keep API keys on the server; never embed private API keys in the APK.
- Alarm and timer creation is delegated to the user's Clock app. Contact calls open the dialer for user confirmation.
- Android manufacturers and versions vary; permissions and background execution policies may limit overlay and wake-word behaviour.

## Permissions
Microphone and contacts are requested at runtime. The floating overlay requires the user to enable “Display over other apps” in Android settings. Calls use the dialer rather than placing a call automatically.
