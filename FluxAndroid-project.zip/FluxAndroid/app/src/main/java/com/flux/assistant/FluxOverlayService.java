package com.flux.assistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

public class FluxOverlayService extends Service {
    private WindowManager wm; private TextView bubble;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onCreate(){super.onCreate(); if(!Settings.canDrawOverlays(this)){stopSelf();return;} wm=(WindowManager)getSystemService(WINDOW_SERVICE); bubble=new TextView(this); bubble.setText("✦ FLUX"); bubble.setTextColor(Color.WHITE); bubble.setTextSize(13); bubble.setGravity(Gravity.CENTER); GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff36dfff,0xff6357ff,0xff211b54}); bg.setShape(GradientDrawable.OVAL); bg.setStroke(3,0xffb9f7ff); bubble.setBackground(bg); bubble.setElevation(12f); bubble.setOnClickListener(v->{Intent a=new Intent(this,MainActivity.class);a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(a);});
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(88,88,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT); p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; p.x=18; wm.addView(bubble,p);
    }
    @Override public void onDestroy(){if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}super.onDestroy();}
}
