package com.flux.assistant;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

public class OrbDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    @Override public void draw(Canvas c) {
        float x=getBounds().centerX(), y=getBounds().centerY();
        float r=Math.min(getBounds().width(),getBounds().height())*.48f;
        paint.setShader(new RadialGradient(x-r*.22f,y-r*.28f,r*1.25f,new int[]{0xffe7ffff,0xff47dfff,0xff536bff,0xff30215f},null,Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,paint); paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3); paint.setColor(0x99b9f7ff); c.drawCircle(x,y,r+5,paint); paint.setStyle(Paint.Style.FILL);
    }
    @Override public void setAlpha(int a){paint.setAlpha(a);} @Override public void setColorFilter(android.graphics.ColorFilter f){paint.setColorFilter(f);} @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
}
