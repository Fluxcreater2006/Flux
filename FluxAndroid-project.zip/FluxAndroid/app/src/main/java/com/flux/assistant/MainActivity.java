package com.flux.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 41;
    private static final int REQ_PERMS = 42;
    private TextView status;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,11,24));
        getWindow().setNavigationBarColor(Color.rgb(8,11,24));
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) { ttsReady = true; tts.setLanguage(Locale.getDefault()); } });
        buildUi();
        requestRuntimePermissions();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(28, 42, 28, 24); root.setBackgroundColor(Color.rgb(8,11,24));
        TextView title = new TextView(this); title.setText("FLUX"); title.setTextColor(Color.rgb(72,217,255)); title.setTextSize(34); title.setGravity(Gravity.CENTER); title.setLetterSpacing(.18f);
        root.addView(title, new LinearLayout.LayoutParams(-1, 60));
        TextView sub = new TextView(this); sub.setText("YOUR PERSONAL AI ASSISTANT"); sub.setTextColor(0xffA9B8D8); sub.setTextSize(11); sub.setGravity(Gravity.CENTER); root.addView(sub);
        TextView orb = new TextView(this); orb.setText("✦\nFLUX"); orb.setTextColor(Color.WHITE); orb.setTextSize(22); orb.setGravity(Gravity.CENTER); orb.setBackground(new OrbDrawable());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(230,230); op.gravity=Gravity.CENTER; op.topMargin=32; op.bottomMargin=28; root.addView(orb,op);
        status = new TextView(this); status.setText("Ready. Tap the orb and speak."); status.setTextColor(0xffD7E5FF); status.setTextSize(15); status.setGravity(Gravity.CENTER); root.addView(status, new LinearLayout.LayoutParams(-1,54));
        Button listen = button("🎙  TALK TO FLUX"); listen.setOnClickListener(v -> startSpeech()); root.addView(listen, fullWidth());
        Button type = button("TYPE A COMMAND"); type.setOnClickListener(v -> showTextCommand()); root.addView(type, fullWidth());
        Button floatBtn = button("ENABLE FLOATING FLUX"); floatBtn.setOnClickListener(v -> enableOverlay()); root.addView(floatBtn, fullWidth());
        Button clock = button("TIME & DATE"); clock.setOnClickListener(v -> sayNow()); root.addView(clock, fullWidth());
        TextView note = new TextView(this); note.setText("Offline commands work on-device. Online AI and a true always-listening ‘Hey Flux’ wake word need additional model/service setup."); note.setTextColor(0xff8292B4); note.setTextSize(11); note.setGravity(Gravity.CENTER); note.setPadding(8,22,8,0); root.addView(note);
        setContentView(root);
    }
    private LinearLayout.LayoutParams fullWidth(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,54); p.topMargin=9; return p; }
    private Button button(String text){ Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff172A4B)); return b; }
    private void requestRuntimePermissions(){ ArrayList<String> p=new ArrayList<>(); if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO); if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_CONTACTS); if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),REQ_PERMS); }

    private void startSpeech(){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to Flux");
        try { startActivityForResult(i,REQ_SPEECH); } catch(ActivityNotFoundException e){ speak("Speech recognition is not available on this device."); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){ super.onActivityResult(request,result,data); if(request==REQ_SPEECH && result==RESULT_OK && data!=null){ ArrayList<String> matches=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(matches!=null&&!matches.isEmpty()) handleCommand(matches.get(0)); } }
    private void showTextCommand(){ EditText input=new EditText(this); input.setHint("Try: open YouTube, set a timer for 2 minutes"); new AlertDialog.Builder(this).setTitle("Ask Flux").setView(input).setPositiveButton("Run",(d,w)->handleCommand(input.getText().toString())).setNegativeButton("Cancel",null).show(); }

    private void handleCommand(String raw){
        String c=raw.toLowerCase(Locale.ROOT).trim(); status.setText("You: "+raw);
        if(c.contains("time")||c.contains("date")||c.contains("समय")||c.contains("तारीख")){ sayNow(); return; }
        if(c.contains("timer")||c.contains("टाइमर")){ int mins=numberBeforeUnit(c,"minute", "minutes", "मिनट"); if(mins<=0)mins=1; Intent i=new Intent(AlarmClock.ACTION_SET_TIMER); i.putExtra(AlarmClock.EXTRA_LENGTH,mins*60); i.putExtra(AlarmClock.EXTRA_MESSAGE,"Flux timer"); i.putExtra(AlarmClock.EXTRA_SKIP_UI,false); launch(i,"Opening timer for "+mins+" minutes."); return; }
        if(c.contains("alarm")||c.contains("अलार्म")){ int h=numberBeforeUnit(c,"hour","hours","घंटे"); int m=numberBeforeUnit(c,"minute","minutes","मिनट"); Calendar cal=Calendar.getInstance(); cal.add(Calendar.HOUR_OF_DAY,h); cal.add(Calendar.MINUTE,m); Intent i=new Intent(AlarmClock.ACTION_SET_ALARM); i.putExtra(AlarmClock.EXTRA_HOUR,cal.get(Calendar.HOUR_OF_DAY)); i.putExtra(AlarmClock.EXTRA_MINUTES,cal.get(Calendar.MINUTE)); i.putExtra(AlarmClock.EXTRA_MESSAGE,"Flux alarm"); launch(i,"Opening alarm setup."); return; }
        if(c.startsWith("call ")||c.startsWith("कॉल ")){ String who=raw.substring(raw.indexOf(' ')+1).trim(); callContact(who); return; }
        if(c.startsWith("open ")||c.startsWith("खोलो ")||c.startsWith("खोल ")){ String app=raw.substring(raw.indexOf(' ')+1).trim(); openApp(app); return; }
        if(c.contains("stopwatch")){ launch(new Intent("android.intent.action.SHOW_TIMERS"),"Opening clock."); return; }
        speak("I can do that basic task when you give me a supported command. Try open an app, set an alarm, set a timer, call a contact, or ask for the time.");
    }
    private int numberBeforeUnit(String c,String a,String b,String hindi){ java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+)").matcher(c); if(m.find())try{return Integer.parseInt(m.group(1));}catch(Exception ignored){} return 0; }
    private void sayNow(){ String s="It is "+DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date())+" on "+DateFormat.getDateInstance(DateFormat.FULL).format(new Date()); speak(s); }
    private void launch(Intent i,String msg){ try{ if(i.resolveActivity(getPackageManager())!=null){startActivity(i);speak(msg);}else speak("That feature is not available on this device."); }catch(Exception e){speak("I could not open that feature.");} }
    private void openApp(String name){
        try { Intent main=new Intent(Intent.ACTION_MAIN,null); main.addCategory(Intent.CATEGORY_LAUNCHER); for(android.content.pm.ResolveInfo r:getPackageManager().queryIntentActivities(main,0)){ CharSequence label=r.loadLabel(getPackageManager()); if(label!=null && label.toString().toLowerCase(Locale.ROOT).contains(name.toLowerCase(Locale.ROOT))){ Intent launch=getPackageManager().getLaunchIntentForPackage(r.activityInfo.packageName); if(launch!=null){startActivity(launch);speak("Opening "+label);return;} } } speak("I could not find an app named "+name); }catch(Exception e){speak("I could not open that app.");}
    }
    private void callContact(String name){
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){speak("Please allow contacts permission first.");return;}
        Cursor cur=null; try { cur=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" LIKE ?",new String[]{"%"+name+"%"},null); if(cur!=null&&cur.moveToFirst()){String number=cur.getString(0); String contact=cur.getString(1); new AlertDialog.Builder(this).setTitle("Call "+contact+"?").setMessage(number).setPositiveButton("Open dialer",(d,w)->{Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number)));startActivity(i);}).setNegativeButton("Cancel",null).show();}else speak("I could not find that contact."); }catch(Exception e){speak("I could not search contacts.");}finally{if(cur!=null)cur.close();}
    }
    private void enableOverlay(){ if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);return;} startService(new Intent(this,FluxOverlayService.class)); speak("Floating Flux is enabled."); }
    private void speak(String text){ status.setText(text); if(ttsReady)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"flux"); }
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}
}
