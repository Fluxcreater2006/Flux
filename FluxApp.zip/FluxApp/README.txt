Flux 2 - upload this zip to your GitHub repo (replace FluxApp.zip). The build downloads the speech model by itself.
Offline commands: turn on Google offline English speech (Google app > Settings > Voice > Offline speech recognition).
