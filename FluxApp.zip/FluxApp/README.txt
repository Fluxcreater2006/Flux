1) Download vosk-model-small-en-in-0.4 from alphacephei.com/vosk/models, unzip it,
   rename the folder to "model" and put it at app/src/main/assets/model
2) (Optional) paste Anthropic key in Config.kt
3) Open in Android Studio -> Build > Build APK(s)
