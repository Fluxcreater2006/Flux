package com.flux.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("flux", 0)
        val tv = TextView(this).apply {
            text = "FLUX\n\n1) Tap START FLUX and allow everything.\n2) Say \"Hey Flux\".\n\nWorks offline. The box below is optional (smart AI answers, needs internet)."
            textSize = 17f
            setPadding(48, 96, 48, 24)
        }
        val key = EditText(this).apply { hint = "Gemini API key (optional)"; setText(prefs.getString("key", "")); setSingleLine() }
        val save = Button(this).apply {
            text = "SAVE KEY"
            setOnClickListener {
                prefs.edit().putString("key", key.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply { text = "START FLUX"; setOnClickListener { begin() } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 0, 24, 0)
            addView(tv); addView(start); addView(key); addView(save)
        })
    }

    private fun begin() {
        requestPermissions(arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION
        ), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != 0) return
        startForegroundService(Intent(this, FluxService::class.java))
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }
}
