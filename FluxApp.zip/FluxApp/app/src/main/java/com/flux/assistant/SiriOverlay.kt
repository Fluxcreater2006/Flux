package com.flux.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** Siri-style glowing colour waves that react to your voice. */
class SiriWaveView(ctx: Context) : View(ctx) {
    private val colors = intArrayOf(
        0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF4081.toInt(), 0xFFFFFFFF.toInt()
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private var phase = 0f
    private var level = 0.12f
    private var shown = 0.12f
    private var running = false
    var speaking = false

    fun setLevel(v: Float) { level = v.coerceIn(0.1f, 1f) }
    fun start() { running = true; invalidate() }
    fun stop() { running = false }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val mid = h / 2f
        level = max(0.1f, level - 0.012f)
        val target = if (speaking) 0.4f + 0.3f * sin(phase * 2.2f) else level
        shown += (target - shown) * 0.2f
        phase += 0.13f
        for (i in colors.indices) {
            val freq = 1.1f + i * 0.45f
            val speed = 1f + i * 0.35f
            val amp = mid * 0.95f * shown * (1f - i * 0.13f)
            path.reset()
            var x = 0f
            while (x <= w) {
                val t = x / w
                val env = 4f * t * (1f - t)
                val y = mid + sin(t * freq * 2f * PI.toFloat() + phase * speed + i) * amp * env * env
                if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                x += 6f
            }
            paint.color = colors[i]
            paint.alpha = 60; paint.strokeWidth = 16f
            c.drawPath(path, paint)
            paint.alpha = 235; paint.strokeWidth = 4f
            c.drawPath(path, paint)
        }
        if (running) postInvalidateOnAnimation()
    }
}

class SiriOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val wave = SiriWaveView(ctx)
    private val caption = TextView(ctx)
    private val root = LinearLayout(ctx)
    private var shown = false

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    init {
        caption.setTextColor(Color.WHITE)
        caption.textSize = 20f
        caption.gravity = Gravity.CENTER
        caption.setPadding(dp(24), 0, dp(24), dp(12))
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.BOTTOM
        root.setPadding(0, dp(90), 0, dp(20))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, 0xCC000000.toInt(), 0xF0000000.toInt())
        )
        root.addView(caption)
        root.addView(wave, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)))
    }

    fun show() {
        if (shown) return
        try {
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.BOTTOM
            wm.addView(root, p)
            shown = true
            wave.start()
        } catch (e: Exception) { /* no overlay permission: Flux still works, just without the animation */ }
    }

    fun hide() {
        if (!shown) return
        wave.stop()
        try { wm.removeView(root) } catch (_: Exception) {}
        shown = false
    }

    fun text(t: String) { caption.text = t }
    fun level(v: Float) { wave.setLevel(v) }
    fun speaking(b: Boolean) { wave.speaking = b }
}
