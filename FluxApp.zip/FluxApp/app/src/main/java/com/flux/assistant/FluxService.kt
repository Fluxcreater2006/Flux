package com.flux.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FluxService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeService: SpeechService? = null
    private var starting = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var overlay: SiriOverlay
    private var afterSpeech: (() -> Unit)? = null
    private val history = mutableListOf<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        overlay = SiriOverlay(this)
        goForeground()
        tts = TextToSpeech(this) {
            if (tts.setLanguage(speechLocale()) < 0) tts.language = Locale.US
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { finishSpeech() }
                override fun onDone(id: String?) { finishSpeech() }
            })
            startWake()
        }
    }

    private fun finishSpeech() {
        val cb = afterSpeech; afterSpeech = null
        main.post { overlay.speaking(false); cb?.invoke() }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("flux", "Flux", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "flux")
            .setContentTitle("Flux is listening")
            .setContentText("Say \"Hey Flux\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ---------- wake word (offline, Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            list.forEach { copyAssets("$path/$it", File(dest, it)) }
        }
    }

    private fun startWake() {
        if (starting || wakeService != null) return
        starting = true
        Thread {
            try {
                if (model == null) {
                    val dir = File(filesDir, "model")
                    if (!File(dir, "ready").exists()) {
                        dir.deleteRecursively()
                        copyAssets("model", dir)
                        File(dir, "ready").writeText("ok")
                    }
                    model = Model(dir.absolutePath)
                }
                val rec = Recognizer(model, 16000f, "[\"hey flux\", \"flux\", \"[unk]\"]")
                main.post {
                    try {
                        val svc = SpeechService(rec, 16000f)
                        wakeService = svc
                        svc.startListening(object : org.vosk.android.RecognitionListener {
                            private fun check(j: String) { if (wakeService != null && j.contains("flux")) onWake() }
                            override fun onPartialResult(h: String?) { if (h != null) check(h) }
                            override fun onResult(h: String?) { if (h != null) check(h) }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) { Log.e("Flux", "vosk", e) }
                            override fun onTimeout() {}
                        })
                    } catch (e: Exception) { Log.e("Flux", "wake start", e) }
                    starting = false
                }
            } catch (e: Exception) { Log.e("Flux", "wake error", e); starting = false }
        }.start()
    }

    private fun stopWake() {
        wakeService?.let { it.stop(); it.shutdown() }
        wakeService = null
    }

    private fun onWake() {
        stopWake()
        overlay.show()
        say("Yes boss?") { listen() }
    }

    private fun resume() {
        recognizer?.destroy(); recognizer = null
        overlay.hide()
        startWake()
    }

    // ---------- speaking and listening ----------
    private fun say(t: String, done: (() -> Unit)? = null) {
        overlay.text(t)
        overlay.speaking(true)
        afterSpeech = done ?: { resume() }
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return say("Speech recognition is not available on this phone")
        overlay.text("Listening...")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) resume() else handle(t)
                }
                override fun onPartialResults(p: Bundle?) {
                    p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { overlay.text(it) }
                }
                override fun onRmsChanged(v: Float) { overlay.level((v + 2f) / 12f) }
                override fun onError(e: Int) { resume() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLocale().toLanguageTag())
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
    }

    // ---------- helpers ----------
    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Log.e("Flux", "launch", e) }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun findContact(name: String): Pair<String, String>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1)) }
        return null
    }

    private fun placeCall(num: String) {
        val action = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        launch(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun findSong(q: String): Uri? {
        if (!has(Manifest.permission.READ_EXTERNAL_STORAGE)) return null
        val words = q.split(" ").filter { it.isNotBlank() }
        val sel = if (words.isEmpty()) null else words.joinToString(" AND ") {
            "(" + MediaStore.Audio.Media.TITLE + " || ' ' || " + MediaStore.Audio.Media.ARTIST + ") LIKE ?"
        }
        val args = if (words.isEmpty()) null else words.map { "%$it%" }.toTypedArray()
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID),
            sel, args, MediaStore.Audio.Media.DATE_ADDED + " DESC"
        )?.use {
            if (it.moveToFirst()) return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.getLong(0))
        }
        return null
    }

    private fun playSong(q: String) {
        val uri = findSong(q) ?: return say("I could not find " + (if (q.isBlank()) "any music" else q) + " on your phone")
        val pm = packageManager
        val pkg = listOf("com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro")
            .firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        say("Playing " + (if (q.isBlank()) "music" else q)) {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "audio/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) i.setPackage(pkg)
            launch(i); resume()
        }
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun toggleWifi(on: Boolean) {
        val ok = try {
            (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).setWifiEnabled(on)
        } catch (e: Exception) { false }
        if (ok) say("Wi-Fi turned " + (if (on) "on" else "off"))
        else say("This phone does not let me do that. Opening Wi-Fi settings.") { launch(Intent(Settings.ACTION_WIFI_SETTINGS)); resume() }
    }

    private fun toggleBluetooth(on: Boolean) {
        val a = BluetoothAdapter.getDefaultAdapter() ?: return say("This phone has no Bluetooth")
        val ok = try { if (on) a.enable() else a.disable() } catch (e: Exception) { false }
        if (ok) say("Bluetooth turned " + (if (on) "on" else "off"))
        else say("This phone does not let me do that. Opening Bluetooth settings.") { launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); resume() }
    }

    private fun toggleTorch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) say("I could not find a flashlight")
            else { cm.setTorchMode(id, on); say("Flashlight " + (if (on) "on" else "off")) }
        } catch (e: Exception) { say("I could not control the flashlight") }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val li = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) say("I could not find $name")
        else say("Opening $name") { launch(li); resume() }
    }

    // ---------- extra helpers (work on any phone) ----------
    private fun speechLocale(): Locale {
        val l = Locale.getDefault()
        return if (l.language == "en") l else Locale.US
    }

    private fun countryCode(): String {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
        val iso = tm.simCountryIso.orEmpty().ifEmpty { Locale.getDefault().country }.uppercase()
        val codes = mapOf(
            "IN" to "91", "US" to "1", "CA" to "1", "GB" to "44", "PK" to "92", "BD" to "880", "LK" to "94",
            "NP" to "977", "AE" to "971", "SA" to "966", "AU" to "61", "NZ" to "64", "SG" to "65", "MY" to "60",
            "ZA" to "27", "NG" to "234", "KE" to "254", "DE" to "49", "FR" to "33", "IT" to "39", "ES" to "34",
            "BR" to "55", "MX" to "52", "ID" to "62", "PH" to "63", "TR" to "90", "RU" to "7", "EG" to "20", "JP" to "81"
        )
        return codes[iso] ?: ""
    }

    private fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.removePrefix("00")
        d = d.trimStart('0')
        val cc = countryCode()
        return if (cc.isNotEmpty() && d.length <= 10) cc + d else d
    }

    private fun sendWhatsApp(rest: String) {
        val r = rest.trim()
        val words = r.split(" ").filter { it.isNotBlank() }
        var found: Pair<String, String>? = null
        var text = ""
        val sep = Regex("^(.+?)\\s+(?:saying|that says|with message|message)\\s+(.+)$").find(r)
        if (sep != null) { found = findContact(sep.groupValues[1].trim()); text = sep.groupValues[2] }
        if (found == null) {
            for (n in 1..minOf(3, words.size - 1)) {
                val f = findContact(words.take(n).joinToString(" "))
                if (f != null) { found = f; text = words.drop(n).joinToString(" "); break }
            }
        }
        val contact = found ?: return say("I could not find that contact")
        text = text.trim().removePrefix(":").trim()
        if (text.isBlank()) return say("What should the message say?")
        val pm = packageManager
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pm.getLaunchIntentForPackage(it) != null }
            ?: return say("WhatsApp is not installed")
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=" + waNumber(contact.second) + "&text=" + Uri.encode(text))
        say("Opening WhatsApp for " + contact.first + ". Tap send.") {
            launch(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); resume()
        }
    }

    private fun contactName(num: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return num
        try {
            contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (_: Exception) {}
        return num
    }

    private fun readLastSms() {
        if (!has(Manifest.permission.READ_SMS)) return say("I need SMS permission. Open Flux and allow it.")
        try {
            contentResolver.query(
                Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC LIMIT 1"
            )?.use {
                if (it.moveToFirst()) {
                    val addr = it.getString(0) ?: ""
                    val body = (it.getString(1) ?: "").take(400)
                    return say("Message from " + contactName(addr) + ". " + body)
                }
            }
            say("You have no messages")
        } catch (e: Exception) { say("I could not read your messages") }
    }

    private fun describeLocation(loc: Location) {
        Thread {
            var place: String? = null
            try {
                if (Geocoder.isPresent()) {
                    val a = Geocoder(this, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                    if (!a.isNullOrEmpty()) place = a[0].getAddressLine(0)
                }
            } catch (_: Exception) {}
            val msg = if (place != null) "You are at $place"
            else "Your location is latitude " + "%.4f".format(loc.latitude) + ", longitude " + "%.4f".format(loc.longitude) +
                ". I need internet to tell the place name."
            main.post { say(msg) }
        }.start()
    }

    private fun whereAmI() {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) return say("I need location permission. Open Flux and allow it.")
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 120000) return describeLocation(last)
        val gps = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
        val net = try { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { false }
        if (!gps && !net) {
            if (last != null) return describeLocation(last)
            return say("Location is off. Opening settings.") { launch(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); resume() }
        }
        overlay.text("Finding your location...")
        var done = false
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) { if (!done) { done = true; describeLocation(loc) } }
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            lm.requestSingleUpdate(if (gps) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER, l, Looper.getMainLooper())
        } catch (e: Exception) { return say("I could not get your location") }
        main.postDelayed({
            if (!done) {
                done = true
                try { lm.removeUpdates(l) } catch (_: Exception) {}
                if (last != null) describeLocation(last) else say("I could not get your location")
            }
        }, 20000)
    }

    private fun setBrightness(level: Int) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            return say("I need permission to change brightness. Opening settings.") {
                launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); resume()
            }
        }
        try {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(1, 255))
            say("Brightness set")
        } catch (e: Exception) { say("I could not change the brightness") }
    }

    private fun brightnessCommand(c: String) {
        val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        val pct = Regex("(\\d{1,3})\\s*(?:percent|%)").find(c)?.groupValues?.get(1)?.toInt()
        when {
            pct != null -> setBrightness(pct.coerceIn(1, 100) * 255 / 100)
            Regex("\\b(full|max|maximum|highest)\\b").containsMatchIn(c) -> setBrightness(255)
            Regex("\\b(half|medium)\\b").containsMatchIn(c) -> setBrightness(128)
            Regex("\\b(low|min|minimum|lowest|dim)\\b").containsMatchIn(c) -> setBrightness(20)
            "up" in c || "increase" in c -> setBrightness(cur + 60)
            "down" in c || "decrease" in c || "lower" in c -> setBrightness(cur - 60)
            else -> say("Say brightness full, half, low, or a percent.")
        }
    }

    private fun soundMode(mode: String) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.ringerMode = when (mode) {
                "silent" -> AudioManager.RINGER_MODE_SILENT
                "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                else -> AudioManager.RINGER_MODE_NORMAL
            }
            say(mode.replaceFirstChar { it.uppercase() } + " mode on")
        } catch (e: SecurityException) {
            try {
                am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                say("Vibrate mode on. For full silent, allow Do Not Disturb access for Flux.") {
                    launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); resume()
                }
            } catch (e2: Exception) { say("I could not change the sound mode") }
        }
    }

    private val jokes = listOf(
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "I told my phone I needed space. It opened the gallery.",
        "Why was the computer cold? It left its Windows open.",
        "I would tell you a UDP joke, but you might not get it.",
        "My battery and I have a lot in common. We both run out of energy by evening.",
        "Why did the phone go to school? To get smarter.",
        "I asked the AI for a joke about time. It said, wait for it."
    )

    // ---------- commands ----------
    private fun handle(raw: String) {
        val c = raw.lowercase().trim().replace("wi-fi", "wifi").replace("wi fi", "wifi")
        overlay.text(c)
        Log.d("Flux", "heard: $c")

        if (Regex("^(stop|cancel|never mind|go to sleep)$").containsMatchIn(c)) return say("Okay, standby.")

        // calls
        Regex("^(?:call|phone|dial) (?:to )?([\\d\\s]{6,})$").find(c)?.let {
            return say("Calling") { placeCall(it.groupValues[1].replace(" ", "")); resume() }
        }
        Regex("^(?:call|phone|dial) (.+)").find(c)?.let {
            val name = it.groupValues[1].trim()
            val f = findContact(name) ?: return say("I could not find $name in your contacts")
            return say("Calling " + f.first) { placeCall(f.second); resume() }
        }
        Regex("number (?:of|for) (.+)").find(c)?.let {
            val name = it.groupValues[1].trim()
            val f = findContact(name) ?: return say("I could not find $name in your contacts")
            val digits = f.second.filter { d -> d.isDigit() }.toCharArray().joinToString(" ")
            return say(f.first + " number is " + digits)
        }

        // whatsapp
        Regex("^send (?:a |an )?(?:whatsapp|whats app)(?: message| msg)?(?: to)? (.+)").find(c)?.let {
            return sendWhatsApp(it.groupValues[1])
        }

        // music
        Regex("^play (.+)").find(c)?.let {
            val q = it.groupValues[1]
                .replace(Regex("\\b(in|on|using) (the )?mx player\\b"), "")
                .replace(Regex("\\b(the|song|songs|music|track)\\b"), "")
                .replace(Regex("\\s+"), " ").trim()
            return playSong(q)
        }
        if (Regex("\\b(pause|hold on)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); return say("Paused") }
        if (Regex("^(resume|continue|play|unpause)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); return say("Resuming") }
        if (Regex("\\b(next|skip)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); return say("Next") }
        if (Regex("\\bprevious\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return say("Previous") }
        if (Regex("^stop (the )?(music|song|video|playing)").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_STOP); return say("Stopped") }

        // sound mode, brightness, location, messages, fun, maths
        if (Regex("\\bsilent\\b").containsMatchIn(c)) return soundMode("silent")
        if (Regex("\\bvibrate mode\\b|\\bvibration mode\\b").containsMatchIn(c)) return soundMode("vibrate")
        if (Regex("\\b(normal|sound|ring|ringing) mode\\b|\\bsound on\\b").containsMatchIn(c)) return soundMode("normal")
        if (Regex("\\bbrightness\\b").containsMatchIn(c)) return brightnessCommand(c)
        if (Regex("where am i|my location|current location").containsMatchIn(c)) return whereAmI()
        if (Regex("\\b(read|check)\\b.*\\b(message|messages|sms|text)\\b").containsMatchIn(c)) return readLastSms()
        if (Regex("\\bjoke\\b").containsMatchIn(c)) return say(jokes.random())
        if (Regex("^open (?:the )?camera").containsMatchIn(c))
            return say("Opening camera") { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); resume() }
        Regex("(-?\\d+(?:\\.\\d+)?)\\s*(plus|\\+|minus|-|times|x|multiplied by|into|divided by|/|over)\\s*(-?\\d+(?:\\.\\d+)?)").find(c)?.let {
            val a = it.groupValues[1].toDouble()
            val b = it.groupValues[3].toDouble()
            val r = when (it.groupValues[2]) {
                "plus", "+" -> a + b
                "minus", "-" -> a - b
                "times", "x", "multiplied by", "into" -> a * b
                else -> if (b == 0.0) return say("I cannot divide by zero") else a / b
            }
            val shown = if (r == Math.floor(r) && Math.abs(r) < 1e12) r.toLong().toString() else "%.2f".format(r)
            return say("The answer is $shown")
        }

        // switches
        val on = Regex("\\b(on|enable)\\b").containsMatchIn(c)
        val off = Regex("\\b(off|disable)\\b").containsMatchIn(c)
        if (on != off) {
            when {
                "wifi" in c -> return toggleWifi(on)
                "bluetooth" in c -> return toggleBluetooth(on)
                "flashlight" in c || "torch" in c || "flash light" in c -> return toggleTorch(on)
                "data" in c || "internet" in c ->
                    return say("Android does not let apps switch mobile data. Opening settings.") {
                        launch(Intent(Settings.ACTION_WIRELESS_SETTINGS)); resume()
                    }
            }
        }

        // volume
        if (Regex("\\b(volume|louder|quieter|mute|unmute)\\b").containsMatchIn(c)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val s = AudioManager.STREAM_MUSIC
            val f = AudioManager.FLAG_SHOW_UI
            when {
                "unmute" in c -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, f)
                "mute" in c -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, f)
                "up" in c || "louder" in c || "increase" in c -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, f) }
                "down" in c || "quieter" in c || "decrease" in c || "lower" in c -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, f) }
                "max" in c || "full" in c -> am.setStreamVolume(s, am.getStreamMaxVolume(s), f)
                else -> return say("Say volume up, volume down, or mute.")
            }
            return say("Done")
        }

        // alarm and timer
        Regex("alarm (?:for|at) (\\d{1,2})(?:[: ](\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(c)?.let {
            var h = it.groupValues[1].toInt()
            val mi = it.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = it.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            if (h in 0..23 && mi in 0..59) {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return say("Alarm set for $h:" + "%02d".format(mi)) { launch(i); resume() }
            }
        }
        Regex("timer (?:for )?(\\d+) ?(second|minute|hour)").find(c)?.let {
            val n = it.groupValues[1].toInt()
            val secs = n * when (it.groupValues[2]) { "hour" -> 3600; "minute" -> 60; else -> 1 }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return say("Timer set for $n " + it.groupValues[2] + (if (n == 1) "" else "s")) { launch(i); resume() }
        }

        // info
        if (Regex("\\btime\\b").containsMatchIn(c))
            return say("Time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
        if (Regex("\\b(date|today|day)\\b").containsMatchIn(c))
            return say("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
        if (Regex("battery").containsMatchIn(c)) {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            return say("Battery is at " + (lvl * 100 / sc) + " percent" + (if (charging) ", charging" else ""))
        }

        // apps and web
        Regex("^open (.+)").find(c)?.let { return openApp(it.groupValues[1].trim()) }
        Regex("^(?:search|google) (?:for )?(.+)").find(c)?.let {
            val q = it.groupValues[1]
            return say("Searching $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); resume() }
        }
        if (Regex("what can you do|help").containsMatchIn(c))
            return say("I can call, send WhatsApp, read messages, tell where you are, play songs, open apps, set alarms, do maths, change brightness and sound mode, and switch Wi-Fi, Bluetooth and the flashlight.")
        if (Regex("^(hello|hi|hey)\\b").containsMatchIn(c)) return say("Hello boss. How can I help?")

        askAI(c)
    }

    // ---------- optional online brain ----------
    private fun askAI(q: String) {
        val prefs = getSharedPreferences("flux", 0)
        val key = prefs.getString("key", "")?.trim().orEmpty()
        if (key.isBlank()) return say("Sorry boss, I did not understand that.")
        Thread {
            val answer = try {
                history += "user" to q
                val contents = JSONArray()
                history.takeLast(8).forEach {
                    contents.put(JSONObject().put("role", it.first)
                        .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Flux, a voice assistant like Jarvis. Reply in at most two short spoken sentences. No markdown, no emojis."))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 800))
                    .toString().toByteArray()
                var text: String? = null
                var lastCode = 0
                for (m in Config.MODELS) {
                    try {
                        val u = "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key"
                        val c = URL(u).openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 25000; c.doOutput = true
                        c.setRequestProperty("content-type", "application/json")
                        c.outputStream.use { it.write(body) }
                        lastCode = c.responseCode
                        val ok = lastCode in 200..299
                        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                        if (ok) {
                            text = JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
                            break
                        } else Log.e("Flux", "ai $m http $lastCode: $s")
                    } catch (e: Exception) { Log.e("Flux", "ai $m", e) }
                }
                if (text.isNullOrBlank()) throw RuntimeException("http $lastCode")
                history += "model" to text
                text
            } catch (e: Exception) {
                history.removeLastOrNull()
                val m = e.message ?: ""
                if (m.startsWith("http ") && m != "http 0") "Sorry, my brain gave error " + m.removePrefix("http ")
                else "Sorry, I could not reach my brain. Are you offline?"
            }
            main.post { say(answer) }
        }.start()
    }

    override fun onDestroy() {
        stopWake(); model?.close()
        recognizer?.destroy(); overlay.hide(); tts.shutdown()
        super.onDestroy()
    }
}
