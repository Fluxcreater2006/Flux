package com.flux.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FluxService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeService: SpeechService? = null
    private var starting = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var afterSpeech: (() -> Unit)? = null
    private val history = mutableListOf<Pair<String, String>>() // role, text

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        goForeground()
        tts = TextToSpeech(this) {
            tts.language = Locale("en", "IN")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { finishSpeech() }
                override fun onDone(id: String?) { finishSpeech() }
            })
            startWake()
        }
    }

    private fun finishSpeech() {
        val cb = afterSpeech; afterSpeech = null
        main.post { cb?.invoke() }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("flux", "Flux", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "flux")
            .setContentTitle("Flux is listening")
            .setContentText("Say \"Hey Flux\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ---------- wake word (offline, Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            list.forEach { copyAssets("$path/$it", File(dest, it)) }
        }
    }

    private fun startWake() {
        if (starting || wakeService != null) return
        starting = true
        Thread {
            try {
                if (model == null) {
                    val dir = File(filesDir, "model")
                    if (!File(dir, "ready").exists()) {
                        dir.deleteRecursively()
                        copyAssets("model", dir)
                        File(dir, "ready").writeText("ok")
                    }
                    model = Model(dir.absolutePath)
                }
                val rec = Recognizer(model, 16000f, "[\"hey flux\", \"flux\", \"[unk]\"]")
                main.post {
                    try {
                        val svc = SpeechService(rec, 16000f)
                        wakeService = svc
                        svc.startListening(object : org.vosk.android.RecognitionListener {
                            private fun check(j: String) {
                                if (wakeService != null && j.contains("flux")) onWake()
                            }
                            override fun onPartialResult(h: String?) { if (h != null) check(h) }
                            override fun onResult(h: String?) { if (h != null) check(h) }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) { Log.e("Flux", "vosk", e) }
                            override fun onTimeout() {}
                        })
                    } catch (e: Exception) { Log.e("Flux", "wake start", e) }
                    starting = false
                }
            } catch (e: Exception) {
                Log.e("Flux", "wake error", e); starting = false
            }
        }.start()
    }

    private fun stopWake() {
        wakeService?.let { it.stop(); it.shutdown() }
        wakeService = null
    }

    private fun onWake() {
        stopWake()
        speak("Yes boss, boliye?") { listen() }
    }

    private fun resume() {
        recognizer?.destroy(); recognizer = null
        startWake()
    }

    // ---------- speech in / out ----------
    private fun speak(t: String, done: (() -> Unit)? = null) {
        afterSpeech = done ?: { resume() }
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) resume() else handle(t.lowercase().trim())
                }
                override fun onError(e: Int) { resume() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"))
        }
    }

    // ---------- commands ----------
    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Log.e("Flux", "launch", e) }
    }

    private fun handle(c: String) {
        Log.d("Flux", "heard: $c")
        Regex("call (?:to )?([\\d\\s]{6,})").find(c)?.let {
            return speak("Calling") { placeCall(it.groupValues[1].replace(" ", "")); resume() }
        }
        Regex("^(?:call|phone|dial) (.+)").find(c)?.let {
            val name = it.groupValues[1].trim()
            val num = findNumber(name)
            return if (num == null) speak("I could not find $name in your contacts")
            else speak("Calling $name") { placeCall(num); resume() }
        }
        when {
            Regex("\\b(stop|cancel|never mind)\\b").containsMatchIn(c) -> speak("Okay, standby.")
            Regex("\\btime\\b").containsMatchIn(c) ->
                speak("Time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            Regex("\\b(date|today)\\b").containsMatchIn(c) ->
                speak("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            c.startsWith("search ") || c.startsWith("google ") -> {
                val q = c.substringAfter(" ")
                speak("Searching $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); resume() }
            }
            c.startsWith("play ") -> {
                val q = c.removePrefix("play ").removeSuffix(" on youtube")
                speak("Playing $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))); resume() }
            }
            c.startsWith("open ") -> openApp(c.removePrefix("open ").trim())
            else -> askAI(c)
        }
    }

    private fun findNumber(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun placeCall(num: String) {
        val ok = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        launch(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val li = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) speak("I could not find $name")
        else speak("Opening $name") { launch(li); resume() }
    }

    // ---------- AI brain (Google Gemini, free tier) ----------
    private fun askAI(q: String) {
        val key = getSharedPreferences("flux", 0).getString("key", "") ?: ""
        if (key.isBlank()) return speak("I did not understand. Put a Gemini key in the app to make me smarter.")
        Thread {
            val answer = try {
                history += "user" to q
                val contents = JSONArray()
                history.takeLast(8).forEach {
                    contents.put(JSONObject().put("role", it.first)
                        .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Flux, a voice assistant like Jarvis. Reply in at most two short spoken sentences. No markdown, no emojis."))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 300)
                        .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
                val u = "https://generativelanguage.googleapis.com/v1beta/models/${Config.MODEL}:generateContent?key=$key"
                val c = URL(u).openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 25000; c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                if (!ok) { Log.e("Flux", "ai http ${c.responseCode}: $s"); throw RuntimeException("http") }
                JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    .trim().also { history += "model" to it }
            } catch (e: Exception) {
                Log.e("Flux", "ai", e); history.removeLastOrNull()
                "Sorry, I could not reach my brain right now."
            }
            main.post { speak(answer) }
        }.start()
    }

    override fun onDestroy() {
        stopWake(); model?.close()
        recognizer?.destroy(); tts.shutdown()
        super.onDestroy()
    }
}
