package com.flux.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FluxService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeService: SpeechService? = null
    private var starting = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var overlay: SiriOverlay
    private var afterSpeech: (() -> Unit)? = null
    private val history = mutableListOf<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        overlay = SiriOverlay(this)
        goForeground()
        tts = TextToSpeech(this) {
            if (tts.setLanguage(Locale("en", "IN")) < 0) tts.language = Locale.US
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { finishSpeech() }
                override fun onDone(id: String?) { finishSpeech() }
            })
            startWake()
        }
    }

    private fun finishSpeech() {
        val cb = afterSpeech; afterSpeech = null
        main.post { overlay.speaking(false); cb?.invoke() }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("flux", "Flux", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "flux")
            .setContentTitle("Flux is listening")
            .setContentText("Say \"Hey Flux\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ---------- wake word (offline, Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            list.forEach { copyAssets("$path/$it", File(dest, it)) }
        }
    }

    private fun startWake() {
        if (starting || wakeService != null) return
        starting = true
        Thread {
            try {
                if (model == null) {
                    val dir = File(filesDir, "model")
                    if (!File(dir, "ready").exists()) {
                        dir.deleteRecursively()
                        copyAssets("model", dir)
                        File(dir, "ready").writeText("ok")
                    }
                    model = Model(dir.absolutePath)
                }
                val rec = Recognizer(model, 16000f, "[\"hey flux\", \"flux\", \"[unk]\"]")
                main.post {
                    try {
                        val svc = SpeechService(rec, 16000f)
                        wakeService = svc
                        svc.startListening(object : org.vosk.android.RecognitionListener {
                            private fun check(j: String) { if (wakeService != null && j.contains("flux")) onWake() }
                            override fun onPartialResult(h: String?) { if (h != null) check(h) }
                            override fun onResult(h: String?) { if (h != null) check(h) }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) { Log.e("Flux", "vosk", e) }
                            override fun onTimeout() {}
                        })
                    } catch (e: Exception) { Log.e("Flux", "wake start", e) }
                    starting = false
                }
            } catch (e: Exception) { Log.e("Flux", "wake error", e); starting = false }
        }.start()
    }

    private fun stopWake() {
        wakeService?.let { it.stop(); it.shutdown() }
        wakeService = null
    }

    private fun onWake() {
        stopWake()
        overlay.show()
        say("Yes boss?") { listen() }
    }

    private fun resume() {
        recognizer?.destroy(); recognizer = null
        overlay.hide()
        startWake()
    }

    // ---------- speaking and listening ----------
    private fun say(t: String, done: (() -> Unit)? = null) {
        overlay.text(t)
        overlay.speaking(true)
        afterSpeech = done ?: { resume() }
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return say("Speech recognition is not available on this phone")
        overlay.text("Listening...")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) resume() else handle(t)
                }
                override fun onPartialResults(p: Bundle?) {
                    p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { overlay.text(it) }
                }
                override fun onRmsChanged(v: Float) { overlay.level((v + 2f) / 12f) }
                override fun onError(e: Int) { resume() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
    }

    // ---------- helpers ----------
    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Log.e("Flux", "launch", e) }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun findContact(name: String): Pair<String, String>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1)) }
        return null
    }

    private fun placeCall(num: String) {
        val action = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        launch(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun findSong(q: String): Uri? {
        if (!has(Manifest.permission.READ_EXTERNAL_STORAGE)) return null
        val words = q.split(" ").filter { it.isNotBlank() }
        val sel = if (words.isEmpty()) null else words.joinToString(" AND ") {
            "(" + MediaStore.Audio.Media.TITLE + " || ' ' || " + MediaStore.Audio.Media.ARTIST + ") LIKE ?"
        }
        val args = if (words.isEmpty()) null else words.map { "%$it%" }.toTypedArray()
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID),
            sel, args, MediaStore.Audio.Media.DATE_ADDED + " DESC"
        )?.use {
            if (it.moveToFirst()) return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.getLong(0))
        }
        return null
    }

    private fun playSong(q: String) {
        val uri = findSong(q) ?: return say("I could not find " + (if (q.isBlank()) "any music" else q) + " on your phone")
        val pm = packageManager
        val pkg = listOf("com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro")
            .firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        say("Playing " + (if (q.isBlank()) "music" else q)) {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "audio/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) i.setPackage(pkg)
            launch(i); resume()
        }
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun toggleWifi(on: Boolean) {
        val ok = try {
            (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).setWifiEnabled(on)
        } catch (e: Exception) { false }
        if (ok) say("Wi-Fi turned " + (if (on) "on" else "off"))
        else say("This phone does not let me do that. Opening Wi-Fi settings.") { launch(Intent(Settings.ACTION_WIFI_SETTINGS)); resume() }
    }

    private fun toggleBluetooth(on: Boolean) {
        val a = BluetoothAdapter.getDefaultAdapter() ?: return say("This phone has no Bluetooth")
        val ok = try { if (on) a.enable() else a.disable() } catch (e: Exception) { false }
        if (ok) say("Bluetooth turned " + (if (on) "on" else "off"))
        else say("This phone does not let me do that. Opening Bluetooth settings.") { launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); resume() }
    }

    private fun toggleTorch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) say("I could not find a flashlight")
            else { cm.setTorchMode(id, on); say("Flashlight " + (if (on) "on" else "off")) }
        } catch (e: Exception) { say("I could not control the flashlight") }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val li = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) say("I could not find $name")
        else say("Opening $name") { launch(li); resume() }
    }

    // ---------- commands ----------
    private fun handle(raw: String) {
        val c = raw.lowercase().trim().replace("wi-fi", "wifi").replace("wi fi", "wifi")
        overlay.text(c)
        Log.d("Flux", "heard: $c")

        if (Regex("^(stop|cancel|never mind|go to sleep)$").containsMatchIn(c)) return say("Okay, standby.")

        // calls
        Regex("^(?:call|phone|dial) (?:to )?([\\d\\s]{6,})$").find(c)?.let {
            return say("Calling") { placeCall(it.groupValues[1].replace(" ", "")); resume() }
        }
        Regex("^(?:call|phone|dial) (.+)").find(c)?.let {
            val name = it.groupValues[1].trim()
            val f = findContact(name) ?: return say("I could not find $name in your contacts")
            return say("Calling " + f.first) { placeCall(f.second); resume() }
        }
        Regex("number (?:of|for) (.+)").find(c)?.let {
            val name = it.groupValues[1].trim()
            val f = findContact(name) ?: return say("I could not find $name in your contacts")
            val digits = f.second.filter { d -> d.isDigit() }.toCharArray().joinToString(" ")
            return say(f.first + " number is " + digits)
        }

        // music
        Regex("^play (.+)").find(c)?.let {
            val q = it.groupValues[1]
                .replace(Regex("\\b(in|on|using) (the )?mx player\\b"), "")
                .replace(Regex("\\b(the|song|songs|music|track)\\b"), "")
                .replace(Regex("\\s+"), " ").trim()
            return playSong(q)
        }
        if (Regex("\\b(pause|hold on)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); return say("Paused") }
        if (Regex("^(resume|continue|play|unpause)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); return say("Resuming") }
        if (Regex("\\b(next|skip)\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); return say("Next") }
        if (Regex("\\bprevious\\b").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return say("Previous") }
        if (Regex("^stop (the )?(music|song|video|playing)").containsMatchIn(c)) { mediaKey(KeyEvent.KEYCODE_MEDIA_STOP); return say("Stopped") }

        // switches
        val on = Regex("\\b(on|enable)\\b").containsMatchIn(c)
        val off = Regex("\\b(off|disable)\\b").containsMatchIn(c)
        if (on != off) {
            when {
                "wifi" in c -> return toggleWifi(on)
                "bluetooth" in c -> return toggleBluetooth(on)
                "flashlight" in c || "torch" in c || "flash light" in c -> return toggleTorch(on)
                "data" in c || "internet" in c ->
                    return say("Android does not let apps switch mobile data. Opening settings.") {
                        launch(Intent(Settings.ACTION_WIRELESS_SETTINGS)); resume()
                    }
            }
        }

        // volume
        if (Regex("\\b(volume|louder|quieter|mute|unmute)\\b").containsMatchIn(c)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val s = AudioManager.STREAM_MUSIC
            val f = AudioManager.FLAG_SHOW_UI
            when {
                "unmute" in c -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, f)
                "mute" in c -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, f)
                "up" in c || "louder" in c || "increase" in c -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, f) }
                "down" in c || "quieter" in c || "decrease" in c || "lower" in c -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, f) }
                "max" in c || "full" in c -> am.setStreamVolume(s, am.getStreamMaxVolume(s), f)
                else -> return say("Say volume up, volume down, or mute.")
            }
            return say("Done")
        }

        // alarm and timer
        Regex("alarm (?:for|at) (\\d{1,2})(?:[: ](\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(c)?.let {
            var h = it.groupValues[1].toInt()
            val mi = it.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = it.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            if (h in 0..23 && mi in 0..59) {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return say("Alarm set for $h:" + "%02d".format(mi)) { launch(i); resume() }
            }
        }
        Regex("timer (?:for )?(\\d+) ?(second|minute|hour)").find(c)?.let {
            val n = it.groupValues[1].toInt()
            val secs = n * when (it.groupValues[2]) { "hour" -> 3600; "minute" -> 60; else -> 1 }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return say("Timer set for $n " + it.groupValues[2] + (if (n == 1) "" else "s")) { launch(i); resume() }
        }

        // info
        if (Regex("\\btime\\b").containsMatchIn(c))
            return say("Time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
        if (Regex("\\b(date|today|day)\\b").containsMatchIn(c))
            return say("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
        if (Regex("battery").containsMatchIn(c)) {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            return say("Battery is at " + (lvl * 100 / sc) + " percent" + (if (charging) ", charging" else ""))
        }

        // apps and web
        Regex("^open (.+)").find(c)?.let { return openApp(it.groupValues[1].trim()) }
        Regex("^(?:search|google) (?:for )?(.+)").find(c)?.let {
            val q = it.groupValues[1]
            return say("Searching $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); resume() }
        }
        if (Regex("what can you do|help").containsMatchIn(c))
            return say("I can call contacts, tell numbers, play songs, pause music, open apps, set alarms, and switch Wi-Fi, Bluetooth and the flashlight.")
        if (Regex("^(hello|hi|hey)\\b").containsMatchIn(c)) return say("Hello boss. How can I help?")

        askAI(c)
    }

    // ---------- optional online brain ----------
    private fun askAI(q: String) {
        val prefs = getSharedPreferences("flux", 0)
        val key = prefs.getString("key", "")?.trim().orEmpty()
        if (key.isBlank()) return say("Sorry boss, I did not understand that.")
        Thread {
            val answer = try {
                history += "user" to q
                val contents = JSONArray()
                history.takeLast(8).forEach {
                    contents.put(JSONObject().put("role", it.first)
                        .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
                }
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Flux, a voice assistant like Jarvis. Reply in at most two short spoken sentences. No markdown, no emojis."))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 800))
                    .toString().toByteArray()
                var text: String? = null
                var lastCode = 0
                for (m in Config.MODELS) {
                    try {
                        val u = "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key"
                        val c = URL(u).openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 25000; c.doOutput = true
                        c.setRequestProperty("content-type", "application/json")
                        c.outputStream.use { it.write(body) }
                        lastCode = c.responseCode
                        val ok = lastCode in 200..299
                        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                        if (ok) {
                            text = JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
                            break
                        } else Log.e("Flux", "ai $m http $lastCode: $s")
                    } catch (e: Exception) { Log.e("Flux", "ai $m", e) }
                }
                if (text.isNullOrBlank()) throw RuntimeException("http $lastCode")
                history += "model" to text
                text
            } catch (e: Exception) {
                history.removeLastOrNull()
                val m = e.message ?: ""
                if (m.startsWith("http ") && m != "http 0") "Sorry, my brain gave error " + m.removePrefix("http ")
                else "Sorry, I could not reach my brain. Are you offline?"
            }
            main.post { say(answer) }
        }.start()
    }

    override fun onDestroy() {
        stopWake(); model?.close()
        recognizer?.destroy(); overlay.hide(); tts.shutdown()
        super.onDestroy()
    }
}
