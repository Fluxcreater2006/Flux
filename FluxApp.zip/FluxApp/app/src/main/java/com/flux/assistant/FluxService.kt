package com.flux.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FluxService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeService: SpeechService? = null
    private var starting = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var afterSpeech: (() -> Unit)? = null
    private val history = mutableListOf<Pair<String, String>>() // role, text

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        goForeground()
        tts = TextToSpeech(this) {
            tts.language = Locale("en", "IN")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { finishSpeech() }
                override fun onDone(id: String?) { finishSpeech() }
            })
            startWake()
        }
    }

    private fun finishSpeech() {
        val cb = afterSpeech; afterSpeech = null
        main.post { cb?.invoke() }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("flux", "Flux", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "flux")
            .setContentTitle("Flux is listening")
            .setContentText("Say \"Hey Flux\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ---------- wake word (offline, Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            list.forEach { copyAssets("$path/$it", File(dest, it)) }
        }
    }

    private fun startWake() {
        if (starting || wakeService != null) return
        starting = true
        Thread {
            try {
                if (model == null) {
                    val dir = File(filesDir, "model")
                    if (!File(dir, "ready").exists()) {
                        dir.deleteRecursively()
                        copyAssets("model", dir)
                        File(dir, "ready").writeText("ok")
                    }
                    model = Model(dir.absolutePath)
                }
                val rec = Recognizer(model, 16000f, "[\"hey flux\", \"flux\", \"[unk]\"]")
                main.post {
                    try {
                        val svc = SpeechService(rec, 16000f)
                        wakeService = svc
                        svc.startListening(object : org.vosk.android.RecognitionListener {
                            private fun check(j: String) {
                                if (wakeService != null && j.contains("flux")) onWake()
                            }
                            override fun onPartialResult(h: String?) { if (h != null) check(h) }
                            override fun onResult(h: String?) { if (h != null) check(h) }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) { Log.e("Flux", "vosk", e) }
                            override fun onTimeout() {}
                        })
                    } catch (e: Exception) { Log.e("Flux", "wake start", e) }
                    starting = false
                }
            } catch (e: Exception) {
                Log.e("Flux", "wake error", e); starting = false
            }
        }.start()
    }

    private fun stopWake() {
        wakeService?.let { it.stop(); it.shutdown() }
        wakeService = null
    }

    private fun onWake() {
        stopWake()
        speak("Yes boss, boliye?") { listen() }
    }

    private fun resume() {
        recognizer?.destroy(); recognizer = null
        startWake()
    }

    // ---------- speech in / out ----------
    private fun speak(t: String, done: (() -> Unit)? = null) {
        afterSpeech = done ?: { resume() }
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) resume() else handle(t.lowercase().trim())
                }
                override fun onError(e: Int) { resume() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"))
        }
    }

    // ---------- commands ----------
    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Log.e("Flux", "launch", e) }
    }

    private fun handle(c: String) {
        Log.d("Flux", "heard: $c")
        Regex("call (?:to )?([\\d\\s]{6,})").find(c)?.let {
            return speak("Calling") { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[1].replace(" ", "")))); resume() }
        }
        when {
            Regex("\\b(stop|cancel|never mind)\\b").containsMatchIn(c) -> speak("Okay, standby.")
            Regex("\\btime\\b").containsMatchIn(c) ->
                speak("Time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            Regex("\\b(date|today)\\b").containsMatchIn(c) ->
                speak("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            c.startsWith("search ") || c.startsWith("google ") -> {
                val q = c.substringAfter(" ")
                speak("Searching $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); resume() }
            }
            c.startsWith("play ") -> {
                val q = c.removePrefix("play ").removeSuffix(" on youtube")
                speak("Playing $q") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))); resume() }
            }
            c.startsWith("open ") -> openApp(c.removePrefix("open ").trim())
            else -> askAI(c)
        }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val li = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) speak("I could not find $name")
        else speak("Opening $name") { launch(li); resume() }
    }

    // ---------- AI brain ----------
    private fun askAI(q: String) {
        if (Config.ANTHROPIC_KEY.isBlank()) return speak("I did not understand. Add an AI key to make me smarter.")
        Thread {
            val answer = try {
                history += "user" to q
                val msgs = JSONArray()
                history.takeLast(8).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                val body = JSONObject()
                    .put("model", "claude-haiku-4-5-20251001")
                    .put("max_tokens", 200)
                    .put("system", "You are Flux, a voice assistant like Jarvis. Reply in at most two short spoken sentences. No markdown.")
                    .put("messages", msgs)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 25000; c.doOutput = true
                c.setRequestProperty("x-api-key", Config.ANTHROPIC_KEY)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val s = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                JSONObject(s).getJSONArray("content").getJSONObject(0).getString("text")
                    .also { history += "assistant" to it }
            } catch (e: Exception) {
                Log.e("Flux", "ai", e); history.removeLastOrNull()
                "Sorry, I could not reach my brain right now."
            }
            main.post { speak(answer) }
        }.start()
    }

    override fun onDestroy() {
        stopWake(); model?.close()
        recognizer?.destroy(); tts.shutdown()
        super.onDestroy()
    }
}
