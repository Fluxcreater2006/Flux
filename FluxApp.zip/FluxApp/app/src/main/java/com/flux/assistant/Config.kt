package com.flux.assistant

object Config {
    // Only used if you paste a Gemini key (online mode, optional). Tried in order.
    val MODELS = listOf("gemini-3.1-flash-lite", "gemini-flash-latest", "gemini-3-flash-preview", "gemini-2.5-flash")
}
