package com.flux.assistant

object Config {
    // Optional: Anthropic API key from console.anthropic.com. Leave "" to disable AI answers.
    // Personal use only: do not share the APK if you put a key here.
    const val ANTHROPIC_KEY = ""
}
