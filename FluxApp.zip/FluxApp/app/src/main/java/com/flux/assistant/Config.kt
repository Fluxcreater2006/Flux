package com.flux.assistant

object Config {
    // Change this name if Google retires the model.
    const val MODEL = "gemini-2.5-flash"
}
